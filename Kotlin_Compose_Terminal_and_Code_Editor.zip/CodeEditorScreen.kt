package com.example.ide.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction

/*
 * CODE EDITOR SCREEN — Jetpack Compose / Material 3
 *
 * This file demonstrates the requested editor layout and local UI behaviour:
 * toolbar, file tabs, numbered code lines, lightweight Kotlin token colouring,
 * diagnostics, completion suggestions, and a compact status bar.
 *
 * IMPORTANT:
 * - This is a UI scaffold, NOT a full language server or production IDE engine.
 * - Replace demo highlighting with an incremental lexer/parser or existing editor engine.
 * - Replace demo diagnostics/completion with your compiler/LSP/project analysis.
 * - For a serious editor, use a purpose-built text editor component (for example,
 *   your existing editor view) rather than one BasicTextField per line.
 * - Keep document state in a ViewModel and persist unsaved buffers safely.
 * - Never run compilation, indexing, parsing, or file I/O on the main thread.
 */

private val EditorBg = Color(0xFF10131D)
private val EditorSurface = Color(0xFF191E2B)
private val EditorBorder = Color(0xFF30394D)
private val EditorText = Color(0xFFE8ECF5)
private val EditorMuted = Color(0xFF8995AA)
private val EditorPurple = Color(0xFF9877FF)
private val EditorBlue = Color(0xFF65B7FF)
private val EditorGreen = Color(0xFF65D6A6)
private val EditorYellow = Color(0xFFE7C46A)
private val EditorRed = Color(0xFFFF777F)

data class EditorFile(
    val id: String,
    val name: String,
    val language: String,
    val content: String,
    val isDirty: Boolean = false
)

data class EditorDiagnostic(
    val lineIndex: Int,
    val message: String,
    val isError: Boolean = true
)

@Composable
fun CodeEditorScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onRun: (file: EditorFile) -> Unit = {},
    onOpenMore: () -> Unit = {}
) {
    val keyboard = LocalSoftwareKeyboardController.current

    // Demo documents. In production, collect these from a ViewModel.
    val files = remember {
        mutableStateListOf(
            EditorFile(
                "main", "MainActivity.kt", "Kotlin",
                """package com.example.app

import androidx.compose.runtime.Composable

@Composable
fun MainActivity() {
    val title = "Hello"
    Greeting(title)
}"""
            ),
            EditorFile(
                "theme", "Theme.kt", "Kotlin",
                """package com.example.app.ui.theme

import androidx.compose.runtime.Composable

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    content()
}"""
            ),
            EditorFile("strings", "strings.xml", "XML",
                """<resources>
    <string name="app_name">My App</string>
</resources>""")
        )
    }

    var activeFileId by remember { mutableStateOf("theme") }
    var showCompletions by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var cursorLine by rememberSaveable { mutableIntStateOf(8) }
    var cursorColumn by rememberSaveable { mutableIntStateOf(6) }

    val activeIndex = files.indexOfFirst { it.id == activeFileId }.coerceAtLeast(0)
    val activeFile = files[activeIndex]

    // Demonstration diagnostic. Replace with real diagnostics from your compiler/LSP.
    val diagnostics = remember(activeFile.content) {
        if (activeFile.content.contains("Greeting(")) {
            listOf(EditorDiagnostic(7, "Unresolved reference: Greeting"))
        } else emptyList()
    }

    Column(modifier.fillMaxSize().background(EditorBg)) {
        EditorToolbar(
            fileName = activeFile.name,
            onBack = onBack,
            onUndo = { /* Connect to editor undo manager. */ },
            onRedo = { /* Connect to editor redo manager. */ },
            onRun = { keyboard?.hide(); onRun(activeFile) },
            onMore = onOpenMore
        )

        // Horizontally scrollable open-file strip.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            files.forEach { file ->
                val selected = file.id == activeFileId
                Surface(
                    color = if (selected) Color(0xFF30284D) else EditorSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp, if (selected) EditorPurple else EditorBorder
                    ),
                    modifier = Modifier.clickable {
                        activeFileId = file.id
                        showCompletions = false
                    }
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(file.name, color = if (selected) EditorText else EditorMuted, fontSize = 11.sp)
                        if (file.isDirty) {
                            Spacer(Modifier.width(5.dp))
                            Text("•", color = EditorYellow)
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = EditorBorder)

        // Editor workspace. This simple demo uses line rows for visible line
        // numbers and token styling. A production editor should use a single
        // editable document surface with a synchronised gutter.
        val lines = activeFile.content.split("\n")
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(top = 8.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                itemsIndexed(lines) { index, line ->
                    val diagnostic = diagnostics.firstOrNull { it.lineIndex == index }
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (index + 1 == cursorLine) Color(0xFF1B2232) else Color.Transparent)
                            .padding(end = 12.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Gutter: line number and optional diagnostic marker.
                        Row(
                            modifier = Modifier.width(52.dp).padding(end = 9.dp),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (diagnostic != null) {
                                Icon(Icons.Default.Error, null, tint = EditorRed, modifier = Modifier.size(12.dp))
                            }
                            Text("${index + 1}", color = EditorMuted, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace)
                        }

                        // Demo is read-only styled text. Connect this line to
                        // your existing editable editor engine for real editing.
                        Text(
                            text = kotlinHighlighted(line),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 21.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (diagnostic != null) {
                        Row(Modifier.padding(start = 58.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, null, tint = EditorRed, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(diagnostic.message, color = EditorRed, fontSize = 10.sp)
                        }
                    }
                }
            }

            // Completion popup is positioned as an overlay in this sample.
            // A production implementation should anchor it to the actual cursor
            // coordinates and keep it inside the visible editor viewport.
            if (showCompletions) {
                CompletionPopup(
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 58.dp, bottom = 18.dp),
                    onSelect = { showCompletions = false }
                )
            }
        }

        // Bottom status strip. Cursor values should be driven by the real editor.
        Row(
            Modifier.fillMaxWidth().background(EditorSurface).padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(activeFile.language, color = EditorBlue, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text("Ln $cursorLine, Col $cursorColumn", color = EditorMuted, fontSize = 10.sp)
            Spacer(Modifier.width(14.dp))
            Text("UTF-8", color = EditorMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun EditorToolbar(
    fileName: String,
    onBack: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onRun: () -> Unit,
    onMore: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = EditorText) }
        Column(Modifier.weight(1f)) {
            Text(fileName, color = EditorText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("Project editor", color = EditorMuted, fontSize = 10.sp)
        }
        IconButton(onClick = onUndo) { Icon(Icons.Default.Undo, "Undo", tint = EditorMuted) }
        IconButton(onClick = onRedo) { Icon(Icons.Default.Redo, "Redo", tint = EditorMuted) }
        FilledIconButton(
            onClick = onRun,
            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF176B4D))
        ) { Icon(Icons.Default.PlayArrow, "Run", tint = EditorGreen) }
        IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More options", tint = EditorMuted) }
    }
}

@Composable
private fun CompletionPopup(modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    val suggestions = listOf(
        "Composable  — Annotation",
        "Column       — Layout",
        "Modifier     — UI modifier",
        "remember     — State"
    )
    Surface(
        modifier = modifier.widthIn(max = 270.dp),
        color = Color(0xFF242B3C),
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, EditorBorder)
    ) {
        Column(Modifier.padding(vertical = 5.dp)) {
            suggestions.forEach { suggestion ->
                Text(
                    suggestion,
                    color = EditorText,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(suggestion) }
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                )
            }
        }
    }
}

/*
 * Lightweight demonstration highlighter.
 * This is intentionally NOT a full Kotlin lexer: it highlights common keywords,
 * annotations, and quoted strings. Replace it with a tokeniser that handles
 * comments, raw strings, generics, nested expressions, and multiline syntax.
 */
@Composable
private fun kotlinHighlighted(line: String) = buildAnnotatedString {
    val keywords = setOf("package", "import", "fun", "val", "var", "class", "return",
        "if", "else", "when", "for", "while", "object", "interface", "private", "public")
    val parts = Regex("""(@[A-Za-z_]\w*|"[^"]*"|\b[A-Za-z_]\w*\b)""").findAll(line)
    var last = 0
    for (match in parts) {
        append(line.substring(last, match.range.first))
        val token = match.value
        val colour = when {
            token.startsWith("@") -> EditorYellow
            token.startsWith("\"") -> EditorGreen
            token in keywords -> EditorPurple
            token.firstOrNull()?.isUpperCase() == true -> EditorBlue
            else -> EditorText
        }
        withStyle(SpanStyle(color = colour, fontWeight = if (token in keywords) FontWeight.SemiBold else FontWeight.Normal)) {
            append(token)
        }
        last = match.range.last + 1
    }
    append(line.substring(last))
}
