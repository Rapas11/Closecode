# Kotlin Compose UI mockups

This package contains two UI starter implementations:

- `TerminalScreen.kt`
- `CodeEditorScreen.kt`

## Requirements
- Kotlin
- Jetpack Compose
- Material 3
- Material Icons Extended (for the sample icon set)

Add the relevant Compose Material 3 and extended icons dependencies to your app.

## Important integration notes
These files are commented UI scaffolds, not a complete IDE backend.

### Terminal
Connect `onExecuteCommand` to the project's existing shell/session service. Do not execute shell processes on the main thread. Move message history and saved commands into a ViewModel/repository for persistence.

### Code editor
The editor file demonstrates the visual structure and a lightweight token-colouring example. It is not a full editable IDE engine, compiler, language server, or production autocomplete implementation. The code area in this sample is display-oriented; connect the layout to the project's existing editor engine for actual text editing, selection, cursor management, diagnostics, and completion. For performance, use incremental parsing/highlighting and keep expensive work off the UI thread.

## Package names
The sample package names are `com.example.ide.ui.terminal` and `com.example.ide.ui.editor`. Change them to match your application.

## Version compatibility
The snippets use current Compose Material 3 APIs. Depending on your Compose BOM/version, `FlowRow`, icon APIs, or Material 3 components may require corresponding dependencies or opt-in annotations.
