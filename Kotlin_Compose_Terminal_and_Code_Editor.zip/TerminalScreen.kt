package com.example.ide.ui.terminal

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import kotlinx.coroutines.launch

/*
 * TERMINAL SCREEN — Jetpack Compose / Material 3
 *
 * This is a UI implementation scaffold for the supplied Terminal mockup.
 * It includes working local UI interactions (tabs, collapse/expand, add/cancel,
 * command selection, shell switching, and settings navigation).
 *
 * IMPORTANT INTEGRATION POINTS:
 * 1. Replace onExecuteCommand with your real terminal process/session runner.
 * 2. Replace the sample shell output with real stdout/stderr events.
 * 3. Persist savedCommands and selectedShell in your ViewModel/repository.
 * 4. Keep terminal process I/O off the Android main thread.
 * 5. Use your app's theme tokens instead of the sample colours if available.
 */

private val TerminalBg = Color(0xFF10131D)
private val TerminalSurface = Color(0xFF191E2B)
private val TerminalSurface2 = Color(0xFF202638)
private val TerminalBorder = Color(0xFF30394D)
private val TerminalText = Color(0xFFE8ECF5)
private val TerminalMuted = Color(0xFF929DB2)
private val TerminalPurple = Color(0xFF9877FF)
private val TerminalGreen = Color(0xFF42D69A)
private val TerminalBlue = Color(0xFF65A9FF)

enum class TerminalSection { SHELLS, SAVED_COMMANDS }

data class TerminalMessage(
    val id: Long,
    val isUser: Boolean,
    val text: String,
    val time: String = "now"
)

data class SavedTerminalCommand(
    val id: Long,
    val name: String,
    val command: String,
    val description: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onExecuteCommand: suspend (shellId: String, command: String) -> String = { _, command ->
        // DEMO ONLY: Replace this with your actual terminal execution service.
        "Command submitted: $command"
    }
) {
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    var section by rememberSaveable { mutableStateOf(TerminalSection.SHELLS) }
    var savedExpanded by rememberSaveable { mutableStateOf(false) }
    var selectedShell by rememberSaveable { mutableStateOf("Shell 1") }
    var commandInput by rememberSaveable { mutableStateOf("") }
    var isAddingCommand by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var isExecuting by remember { mutableStateOf(false) }

    // Demo messages. In production, expose a StateFlow<List<TerminalMessage>>
    // from a ViewModel and collect it with collectAsStateWithLifecycle().
    val messages = remember {
        mutableStateListOf(
            TerminalMessage(1, true, "ls -la", "09:41"),
            TerminalMessage(2, false, "app   build.gradle.kts   gradle\nsettings.gradle.kts", "09:41"),
            TerminalMessage(3, true, "pwd", "09:42"),
            TerminalMessage(4, false, "/home/project/Blank_app", "09:42")
        )
    }

    // Sample commands make the layout demonstrable. Persist this list in a
    // repository/DataStore or database in the real application.
    val savedCommands = remember {
        mutableStateListOf(
            SavedTerminalCommand(1, "List files", "ls -la", "Show files including hidden files"),
            SavedTerminalCommand(2, "Current path", "pwd", "Print working directory"),
            SavedTerminalCommand(3, "Git status", "git status", "Show working tree status"),
            SavedTerminalCommand(4, "Git diff", "git diff", "Show current changes"),
            SavedTerminalCommand(5, "Processes", "ps", "List running processes"),
            SavedTerminalCommand(6, "Clear", "clear", "Clear terminal output")
        )
    }

    if (showSettings) {
        TerminalSettingsScreen(onBack = { showSettings = false })
        return
    }

    Column(
        modifier = modifier.fillMaxSize().background(TerminalBg)
    ) {
        TerminalHeader(
            shellName = selectedShell,
            onBack = onBack,
            onShellSelected = { selectedShell = it },
            onSettings = { showSettings = true }
        )

        // Top-level selector controls one shared content area.
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionTab(
                text = "Shells",
                selected = section == TerminalSection.SHELLS,
                modifier = Modifier.weight(1f)
            ) {
                section = TerminalSection.SHELLS
                savedExpanded = false
                isAddingCommand = false
            }
            SectionTab(
                text = "Saved Commands",
                selected = section == TerminalSection.SAVED_COMMANDS,
                modifier = Modifier.weight(1f)
            ) {
                section = TerminalSection.SAVED_COMMANDS
                savedExpanded = true
                isAddingCommand = false
            }
        }

        // The conversation gets the remaining height. LazyColumn prevents a
        // long terminal history from forcing the whole screen to grow.
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            items(messages, key = { it.id }) { message ->
                TerminalMessageBubble(message)
            }
            if (isExecuting) {
                item { Text("Shell is running…", color = TerminalMuted, fontSize = 12.sp) }
            }
        }

        // Fixed input region: Saved Commands never pushes the input away.
        TerminalCommandInput(
            value = commandInput,
            onValueChange = { commandInput = it },
            enabled = !isExecuting,
            onSend = {
                val command = commandInput.trim()
                if (command.isNotEmpty()) {
                    messages.add(TerminalMessage(System.currentTimeMillis(), true, command))
                    commandInput = ""
                    keyboard?.hide()
                    focusManager.clearFocus()
                    scope.launch {
                        isExecuting = true
                        val result = runCatching { onExecuteCommand(selectedShell, command) }
                            .getOrElse { "Execution error: ${it.message ?: "Unknown error"}" }
                        messages.add(TerminalMessage(System.currentTimeMillis(), false, result))
                        isExecuting = false
                    }
                }
            }
        )

        // Saved Commands is a collapsible panel below the input, as requested.
        // Selecting Shells collapses it; selecting Saved Commands expands it.
        AnimatedVisibility(visible = section == TerminalSection.SAVED_COMMANDS && savedExpanded) {
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .background(TerminalSurface, RoundedCornerShape(18.dp))
                    .animateContentSize()
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Saved Commands", color = TerminalText, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f))
                    TextButton(onClick = { isAddingCommand = !isAddingCommand }) {
                        Icon(Icons.Default.Add, null, tint = TerminalPurple)
                        Spacer(Modifier.width(4.dp))
                        Text(if (isAddingCommand) "Cancel" else "Add Command", color = TerminalPurple)
                    }
                    IconButton(onClick = {
                        savedExpanded = false
                        section = TerminalSection.SHELLS
                        isAddingCommand = false
                    }) {
                        Icon(Icons.Default.ExpandMore, "Collapse saved commands", tint = TerminalMuted)
                    }
                }

                if (isAddingCommand) {
                    AddCommandForm(
                        onCancel = { isAddingCommand = false },
                        onSave = { name, command, description ->
                            savedCommands.add(SavedTerminalCommand(
                                System.currentTimeMillis(), name, command, description
                            ))
                            isAddingCommand = false
                        }
                    )
                } else {
                    // Adaptive grid-like FlowRow; commands wrap on smaller screens.
                    androidx.compose.foundation.layout.FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        savedCommands.forEach { saved ->
                            Surface(
                                color = TerminalSurface2,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.clickable {
                                    // Safer default: insert for review; user presses Send.
                                    commandInput = saved.command
                                    section = TerminalSection.SHELLS
                                    savedExpanded = false
                                }
                            ) {
                                Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                                    Text(saved.name, color = TerminalText, fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold)
                                    Text(saved.command, color = TerminalGreen, fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                    Text("Tap a command to place it in the input for review.",
                        color = TerminalMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
    }
}

@Composable
private fun TerminalHeader(
    shellName: String,
    onBack: () -> Unit,
    onShellSelected: (String) -> Unit,
    onSettings: () -> Unit
) {
    var shellMenu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 6.dp, end = 10.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TerminalText) }
        Icon(Icons.Default.Terminal, null, tint = TerminalPurple)
        Spacer(Modifier.width(8.dp))
        Text("Terminal", color = TerminalText, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f))
        Box {
            Surface(
                color = TerminalSurface2, shape = RoundedCornerShape(10.dp),
                modifier = Modifier.clickable { shellMenu = true }
            ) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(shellName, color = TerminalText, fontSize = 12.sp)
                    Icon(Icons.Default.ArrowDropDown, null, tint = TerminalMuted)
                }
            }
            DropdownMenu(expanded = shellMenu, onDismissRequest = { shellMenu = false }) {
                listOf("Shell 1", "Shell 2", "Shell 3").forEach { shell ->
                    DropdownMenuItem(text = { Text(shell) }, onClick = {
                        onShellSelected(shell); shellMenu = false
                    })
                }
            }
        }
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Terminal settings", tint = TerminalMuted) }
    }
}

@Composable
private fun SectionTab(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(42.dp).clickable(onClick = onClick),
        color = if (selected) Color(0xFF30284D) else TerminalSurface,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp, if (selected) TerminalPurple.copy(alpha = .65f) else TerminalBorder
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, color = if (selected) TerminalText else TerminalMuted,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, fontSize = 13.sp)
        }
    }
}

@Composable
private fun TerminalMessageBubble(message: TerminalMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(.88f),
            horizontalAlignment = if (message.isUser) Alignment.End else Alignment.Start
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!message.isUser) Icon(Icons.Default.Terminal, null, tint = TerminalGreen, modifier = Modifier.size(14.dp))
                Text(if (message.isUser) "USER" else "SHELL", color = if (message.isUser) TerminalBlue else TerminalGreen,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(message.time, color = TerminalMuted, fontSize = 10.sp)
                if (message.isUser) {
                    Spacer(Modifier.width(5.dp))
                    Icon(Icons.Default.Person, null, tint = TerminalBlue, modifier = Modifier.size(14.dp))
                }
            }
            Surface(
                color = if (message.isUser) Color(0xFF242C43) else TerminalSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
            ) {
                Text(
                    message.text,
                    modifier = Modifier.padding(12.dp),
                    color = if (message.isUser) TerminalText else Color(0xFFB9E8D5),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun TerminalCommandInput(
    value: String,
    onValueChange: (String) -> Unit,
    enabled: Boolean,
    onSend: () -> Unit
) {
    Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Terminal, null, tint = TerminalGreen)
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(color = TerminalText, fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                decorationBox = { inner ->
                    if (value.isEmpty()) Text("Type a command…", color = TerminalMuted, fontSize = 13.sp)
                    inner()
                }
            )
            IconButton(onClick = onSend, enabled = enabled && value.isNotBlank()) {
                Icon(Icons.Default.Send, "Send command", tint = TerminalPurple)
            }
        }
    }
}

@Composable
private fun AddCommandForm(
    onCancel: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf("") }
    var command by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Command name") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(command, { command = it }, label = { Text("Command text") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(description, { description = it }, label = { Text("Description (optional)") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onCancel) { Text("Cancel") }
            Button(onClick = { onSave(name.trim(), command.trim(), description.trim()) },
                enabled = name.isNotBlank() && command.isNotBlank()) { Text("Save") }
        }
    }
}

@Composable
fun TerminalSettingsScreen(onBack: () -> Unit) {
    // These are UI examples. Bind them to a settings ViewModel/DataStore.
    var fontSize by rememberSaveable { mutableFloatStateOf(13f) }
    var confirmBeforeRun by rememberSaveable { mutableStateOf(false) }
    var keepHistory by rememberSaveable { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().background(TerminalBg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TerminalText) }
            Text("Terminal Settings", color = TerminalText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Text("APPEARANCE", color = TerminalPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("Font size: ${fontSize.toInt()} sp", color = TerminalText)
        Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 10f..20f)
        HorizontalDivider(color = TerminalBorder)
        Text("COMMAND BEHAVIOUR", color = TerminalPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 18.dp))
        SettingSwitch("Keep command history", keepHistory) { keepHistory = it }
        SettingSwitch("Confirm before running commands", confirmBeforeRun) { confirmBeforeRun = it }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TerminalText, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
